<?php

echo '<h1>test</h1>';
if(isset($_GET['bk'])){
	$bk=$_GET['bk'];
	$puid=$_GET['puid'];
	$cmt=$_GET['cmt'];

}
?>